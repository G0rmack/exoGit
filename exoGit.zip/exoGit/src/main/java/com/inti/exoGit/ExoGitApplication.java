package com.inti.exoGit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExoGitApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExoGitApplication.class, args);
	}

}
